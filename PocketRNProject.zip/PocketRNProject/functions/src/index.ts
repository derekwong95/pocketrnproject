import * as functions from "firebase-functions";
import * as admin from 'firebase-admin';

admin.initializeApp();

const firestoreDB = admin.firestore();
//const cors = require('cors')({origin: true});
// // Start writing Firebase Functions
// // https://firebase.google.com/docs/functions/typescript
//
// export const helloWorld = functions.https.onRequest((request, response) => {
//   functions.logger.info("Hello logs!", {structuredData: true});
//   response.send("Hello from Firebase!");
// });



  export const createAppointment = functions.https.onCall(async (data, context) => {
      await firestoreDB.collection("Appointments").doc(data.guid.value).set({
        guid: data.guid.value,
        userName1: data.curUserName,
        date: data.dateTime,
        userName2: data.userName,
        status: 'Pending'
      });
    return { text: 'Hello from Firebase!' };
  });

  export const getMyAppointment = functions.https.onCall(async (data, context) => {
    const result = await firestoreDB.collection("Appointments").where("userName1", "==", data.curUserName).get();
  return result.docs.map(doc => doc.data());
});

export const getScheduleAppointment = functions.https.onCall(async (data, context) => {
    const result = await firestoreDB.collection("Appointments").where("userName2", "==", data.curUserName).get();
  return result.docs.map(doc => doc.data());
});

export const updateAppointment = functions.https.onCall(async (data, context) => {
    await firestoreDB.collection("Appointments").doc(data.guid).update({
      status: data.status
    });
  return { text: 'Hello from Firebase!' };
});