import React, { useState, useEffect, forwardRef} from "react";
import { Dropdown } from 'react-bootstrap';
import  data  from './../Data/UserData';

var ls = require('local-storage');

export default class UserStore extends React.Component {
    constructor(props: any){
        super(props);

    }
    
    dropdown = data;

    onClickHandler = (event: any) => {
        const value = event.target.id;
        //this.setState({User: value });
        ls.set("userid", this.dropdown.people[value].key);
        ls.set("name", this.dropdown.people[value].name);
        ls.set("age", this.dropdown.people[value].age);


        window.location.reload();
    }

    render() {
        return (     
            <div>
                <Dropdown >
                <Dropdown.Toggle variant="success" id="dropdown-basic">
                    Change current user
                </Dropdown.Toggle>

                <Dropdown.Menu > 
                    {this.dropdown.people.map(x => (
                        <Dropdown.Item key={x.key} id={x.key} onClick={this.onClickHandler}>{x.name}</Dropdown.Item>
                    ))}
                </Dropdown.Menu>
                </Dropdown>
                <div>UserId: {ls.get("userid")}</div>
                <div>Name: {ls.get("name")}</div>
                <div>Age: {ls.get("age")}</div>
                <br></br>
            </div>    
        );
    }
}