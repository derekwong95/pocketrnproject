import React, { useState } from 'react';
import {DateTimePicker, DateTimePickerComponent} from '@syncfusion/ej2-react-calendars';
import UserStore from "./UserStore";
import  data  from './../Data/UserData';
import { Dropdown } from 'react-bootstrap';
import { createAppointment } from './../sdk';
import { Guid } from "guid-typescript";

var ls = require('local-storage');


export default class AppointmentScreen extends React.Component {
  constructor(props: any) {
    super(props);
    //this.state = {value: ''};

    this.handleChangeDateTime = this.handleChangeDateTime.bind(this);
    this.handleChangeUser = this.handleChangeUser.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

  }

  state = {
    guid: Guid.create(),
    curUserId: ls.get("userid"),
    curUserName: ls.get("name"),
    appointment: "",
    userId: "",
    userName: "",
  }

  dropdown = data;

  handleChangeDateTime(event: any) {

    this.setState({
      appointment: event.nativeEvent.text.toString()
    });
    console.log(this.state.appointment);
  }

  handleChangeUser(event: any) {

    this.setState({
        userName: event.target.value
    });
    console.log(this.state.userName);
  }

  handleSubmit(event: any) {

    event.preventDefault();

    //if user did the change 
    if (this.state.userName == "")
    {
      this.setState({
        userName: this.dropdown.people[0].name
      });
    }

    if (this.state.appointment != "" && this.state.userName != "" && this.state.curUserName != this.state.userName)
    {
      //i'm using guid for the document id to keep them unique. I'm also inputing the guid value into the document field section as well.
      //The reason I'm doing that is because I was having issues pulling data out by field value
      this.setState({
        guid: Guid.create()
      });

      createAppointment(this.state.guid, this.state.curUserName, this.state.appointment, this.state.userName);
      alert("Your appointment has been submitted! Please refresh your page to see the most updated information.");
    }
    else if (this.state.userName == this.state.curUserName)
    {
      alert("You cannot make an appointment with yourself!")
    }
    else
    {
      alert("Please fill in the input");
    }
  }

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <DateTimePickerComponent placeholder="Choose your appointment time" onChange={this.handleChangeDateTime} width="300px">
          </DateTimePickerComponent>
          <br></br>
          Choose someone that you want to make an appointment with:  
          <br></br>
          <select onChange={this.handleChangeUser}>
            {this.dropdown.people.map(x => (
              <option key={x.key} value={x.name}>{x.name}</option>
            ))}
          </select>
          <br></br> 
          <input type="submit" value="Submit" />
        </form>
      </div>
    );
  }
}