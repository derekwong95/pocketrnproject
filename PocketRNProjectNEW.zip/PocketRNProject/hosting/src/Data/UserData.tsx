//user data so i can test between different users
type Person = {
    key: number
    name: string
    age: number
}

type People = {
    people: Person[]
}

const data: People = {
    people: [
        {
            key: 0,
            name: "User0",
            age: 32
        },
        {
            key: 1,
            name: "User1",
            age: 53
        },
        {
            key: 2,
            name: "User2",
            age: 12
        },
        {
            key: 3,
            name: "User3",
            age: 34
        },
        {
            key: 4,
            name: "User4",
            age: 23
        },
        {
            key: 5,
            name: "User5",
            age: 33
        }
      ]
}

export default data;

