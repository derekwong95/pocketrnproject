import React, { useEffect, useState } from 'react';
import logo from './logo.svg';
import './App.css';
import { helloWorld, createAppointment, updateAppointment } from './sdk';

import UserStore from "./Componenets/UserStore";
import AppointmentScreen from "./Componenets/AppointmentScreen";

import './../node_modules/bootstrap/dist/css/bootstrap.css';

import { getMyAppointment, getScheduleAppointment } from './sdk';
import { getByTestId } from '@testing-library/dom';
import { AnyARecord } from 'node:dns';

var ls = require('local-storage');


function App() {
  const [appointmentInformation, setAppointmentInformation] = useState<any[]>([])
  const [scheduleInformation, setScheduleInformation] = useState<any[]>([])

  //these are used to bind the data we received from the db to our variables
  useEffect(() => {
      getMyAppointment(ls.get("name")).then(data => setAppointmentInformation(data));
      getScheduleAppointment(ls.get("name")).then(data => setScheduleInformation(data));
  }, [])

  //sends a post request to the db to update the status of the appointment
  const onClick = (event: any) => {
      updateAppointment(event.target.id, event.target.innerText).then(() => {
        window.location.reload();
      })
  }

  return (
    <div className="App">
      <UserStore />
      <h4>Appointment List</h4>
      {appointmentInformation.map(x => 
        <div key={x.guid}>
          <b>Appointment With:</b> {x.userName2} 
          <b>DateTime:</b> {x.date} 
          <b>Status</b> {x.status}
          </div>
          )}

      <br></br>
      <h4>Accept/Decline Appointments</h4>
      {scheduleInformation.map(x => 
        <div key={x.guid}>
          <b>Appointment With: </b> {x.userName1} 
          <b>DateTime: </b> {x.date} 
          <b>Status: </b> {x.status} 
          <button id={x.guid} onClick={onClick}>Accept</button>
          <button id={x.guid} onClick={onClick}>Decline</button>
        </div>
        )}
      <br></br>

      <h3>Schedule your Appointment Below</h3>
      <AppointmentScreen />

    </div>
  );
}

export default App;

