import firebase from "firebase/app";
import 'firebase/functions';

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDLWeozE3KXaifPQBWLXIUnGbspVZx0oJ0",
  authDomain: "pocketrnproject.firebaseapp.com",
  projectId: "pocketrnproject",
  storageBucket: "pocketrnproject.appspot.com",
  messagingSenderId: "277385600888",
  appId: "1:277385600888:web:c72625b90966b322bcb28d",
  measurementId: "G-93LQ35K9QJ"
};

const app = firebase.initializeApp(firebaseConfig);

const firebaseFunctions = app.functions();
firebaseFunctions.useEmulator('localhost', 5001);

export async function helloWorld(): Promise<void> {
  console.log('In Hello World');
  const res = await firebaseFunctions.httpsCallable('helloWorld')({});

  console.log(res + ' test');
}

export async function createAppointment(guid: any,curUserName: any, dateTime: any, userName: any): Promise<void> {
  console.log('In Create Appointment');
  const res = await firebaseFunctions.httpsCallable('createAppointment')({guid, curUserName, dateTime, userName});

  console.log(res);
}

export async function getMyAppointment(curUserName: any): Promise<any> {
  console.log('In Get My Appointment');
  const res = await firebaseFunctions.httpsCallable('getMyAppointment')({curUserName});
  return res.data;
  console.log(res);
}

export async function getScheduleAppointment(curUserName: any): Promise<any> {
  console.log('In Get Schedule Appointment');
  const res = await firebaseFunctions.httpsCallable('getScheduleAppointment')({curUserName});
  return res.data;
  console.log(res);
}

export async function updateAppointment(guid: any, status: any): Promise<void> {
  console.log('In Update Appointment');
  const res = await firebaseFunctions.httpsCallable('updateAppointment')({guid, status});

  console.log(res);
}